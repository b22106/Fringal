package com.app.fringale.Activities.ViewRestaurantsDetailActivity

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.app.fringale.Activities.ViewCartActivity.ViewCartActivity
import com.app.fringale.Adapter.FoodItemsCategoriesAdapter
import com.app.fringale.R
import com.app.fringale.StaticModels.MM
import com.app.fringale.Utils.Utils
import com.app.fringale.databinding.ActivityViewRestaurantsDetailBinding
import com.app.fringale.interfaces.NestedClickListener


class ViewRestaurantsDetailActivity : AppCompatActivity(),NestedClickListener,
    View.OnClickListener {
    private var binding:ActivityViewRestaurantsDetailBinding?=null


    private var foodItemsCategoriesAdapter:FoodItemsCategoriesAdapter?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityViewRestaurantsDetailBinding.inflate(layoutInflater)
        setContentView(binding!!.root)

        listeners()

        foodItemsCategoriesAdapter = FoodItemsCategoriesAdapter(this,this)

        binding!!.fooditemscategoriesrecyclerview .layoutManager = LinearLayoutManager(this,
            LinearLayoutManager.VERTICAL,false)
        binding!!.fooditemscategoriesrecyclerview?.adapter =foodItemsCategoriesAdapter




    }

    private fun listeners(){
        binding!!.imgback.setOnClickListener(this)
        binding!!.InnerRelativeLayout.setOnClickListener(this)
    }
    override fun passData(imgadd: ArrayList<MM>, qnt: Int, value: Int) {

        Toast.makeText(this, value.toString(), Toast.LENGTH_SHORT).show()
        if (value>0){
            binding!!.InnerRelativeLayout.visibility = View.VISIBLE
        }else{

            binding!!.InnerRelativeLayout.visibility = View.GONE

        }
    }

    override fun onClick(p0: View?) {
        when(p0?.id){
            R.id.imgback->{
                finish()
            }
            R.id.InnerRelativeLayout->{
                Utils.movetoActivity(this,ViewCartActivity())

            }
        }
    }


}