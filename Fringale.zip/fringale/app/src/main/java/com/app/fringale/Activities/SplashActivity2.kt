package com.app.fringale.Activities

import android.os.Bundle
import android.os.Handler
import androidx.appcompat.app.AppCompatActivity
import com.app.fringale.Activities.LoginActivtiy.LoginActivtiy
import com.app.fringale.Adapter.ViewPagerAdapter
import com.app.fringale.R
import com.app.fringale.StaticModels.ViewPagerAdapterModel
import com.app.fringale.Utils.Utils
import com.app.fringale.databinding.ActivitySplash2Binding
import java.util.*


class SplashActivity2 : AppCompatActivity() {
    private var binding:ActivitySplash2Binding?=null
    var arraylist:ArrayList<ViewPagerAdapterModel>?=null
    var currentPage = 0
    var timer: Timer? = null
    val DELAY_MS: Long = 500 //delay in milliseconds before task is to be executed

    val PERIOD_MS: Long = 3000 // time in milliseconds between successive task executions.


    // images array
    var images = intArrayOf(
        R.drawable.walkthroughscreen1img, R.drawable.walkthroughscreen2, R.drawable.walkthroughscreen3)

    var mViewPagerAdapter: ViewPagerAdapter? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplash2Binding.inflate(layoutInflater)
        setContentView(binding!!.root)
        // Initializing the ViewPagerAdapter
        // Initializing the ViewPagerAdapter
        arraylist = ArrayList()
        arraylist!!.add(ViewPagerAdapterModel(R.drawable.walkthroughscreen1img,"All your favourites","Order from the best local restaurants with easy ,on-demand delivery"))
        arraylist!!.add(ViewPagerAdapterModel(R.drawable.walkthroughscreen2,"Free delivery offers","Free delivery for new customers via Apple pay and others payment methods"))
        arraylist!!.add(ViewPagerAdapterModel(R.drawable.walkthroughscreen3,"Choose your food","Easily find your type of food craving and you'll get delivery in wide range"))


        mViewPagerAdapter = ViewPagerAdapter(this, arraylist)

        // Adding the Adapter to the ViewPager

        // Adding the Adapter to the ViewPager
        binding!!.viewpager.setAdapter(mViewPagerAdapter)
        binding!!.indicator.setViewPager(binding!!.viewpager)


        val handler = Handler()
        val Update = Runnable {
            if (currentPage === 4 - 1) {
                currentPage = 0
            }
            binding!!.viewpager.setCurrentItem(currentPage++, true)
        }

        timer = Timer() // This will create a new Thread

        timer!!.schedule(object : TimerTask() {
            // task to be scheduled
            override fun run() {
                handler.post(Update)
            }
        }, DELAY_MS, PERIOD_MS)
            binding!!.btngetstarted.setOnClickListener{
                Utils.movetoActivity(this, LoginActivtiy())

            }

    }
}