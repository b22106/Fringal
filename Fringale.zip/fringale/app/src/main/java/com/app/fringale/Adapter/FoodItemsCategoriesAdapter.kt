package com.app.fringale.Adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.app.fringale.R
import com.app.fringale.StaticModels.MM
import com.app.fringale.interfaces.NestedClickListener

class FoodItemsCategoriesAdapter(
    private val activity: FragmentActivity,
    private val listener: NestedClickListener,

) : RecyclerView.Adapter<FoodItemsCategoriesAdapter.ViewHolder>() {


    var isExpandable: Boolean = true
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): FoodItemsCategoriesAdapter.ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.fooditemcategories, parent, false)
        return FoodItemsCategoriesAdapter.ViewHolder(view)
    }


    override fun getItemCount(): Int {
        return 10
    }

    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        var linearopen = itemView.findViewById<LinearLayout>(R.id.linearopen)
        var nestedrecyclerview = itemView.findViewById<RecyclerView>(R.id.nestedrecyclerview)
//        var tv_nameconstructionwork = itemView.findViewById<TextView>(R.id.tv_nameconstructionwork)
//        var tv_pricedetail = itemView.findViewById<TextView>(R.id.tv_pricedetail)
//        var tv_country = itemView.findViewById<TextView>(R.id.tv_country)
//        var tv_jobcity = itemView.findViewById<TextView>(R.id.tv_jobcity)

    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        var nestedFoodItemsRecyclerAdapter:NestedFoodItemsRecyclerAdapter?=null
        nestedFoodItemsRecyclerAdapter   = NestedFoodItemsRecyclerAdapter(activity,listener)


     holder.nestedrecyclerview .layoutManager = LinearLayoutManager(activity,
            LinearLayoutManager.VERTICAL,false)
        holder!!.nestedrecyclerview?.adapter =nestedFoodItemsRecyclerAdapter



        holder.nestedrecyclerview.setVisibility(if (isExpandable) View.VISIBLE else View.GONE)
        holder.linearopen.setOnClickListener{

            if (isExpandable) {
                holder.nestedrecyclerview.setVisibility(if (isExpandable) View.VISIBLE else View.GONE)
                notifyItemChanged(holder.adapterPosition)

            } else {
                holder.nestedrecyclerview.setVisibility(if (isExpandable) View.VISIBLE else View.GONE)

                notifyItemChanged(holder.adapterPosition)





            }
            isExpandable = !isExpandable



            Toast.makeText(activity, isExpandable.toString(), Toast.LENGTH_SHORT).show()


        }

    }
}