package com.app.fringale.Adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.app.fringale.R
import com.app.fringale.StaticModels.MM
import com.app.fringale.interfaces.NestedClickListener
import java.lang.String
import kotlin.Int

class NestedFoodItemsRecyclerAdapter(
    private val activity: FragmentActivity,
   private val listener: NestedClickListener
) : RecyclerView.Adapter<NestedFoodItemsRecyclerAdapter.ViewHolder>() {
    var arrayList:ArrayList<MM> = ArrayList()
    var arrayList2:ArrayList<kotlin.String> = ArrayList()



    var value = 0

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): NestedFoodItemsRecyclerAdapter.ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.nestedrecycleradapteritem, parent, false)
        return NestedFoodItemsRecyclerAdapter.ViewHolder(view)
    }


    override fun getItemCount(): Int {
        return 10
    }

    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        var linear = itemView.findViewById<LinearLayout>(R.id.lin_restaurant)
        var imgadd = itemView.findViewById<ImageView>(R.id.imgadd)
        var tvcount = itemView.findViewById<TextView>(R.id.tvcount)
        var imggsub = itemView.findViewById<ImageView>(R.id.imggsub)
//        var tv_nameconstructionwork = itemView.findViewById<TextView>(R.id.tv_nameconstructionwork)
//        var tv_pricedetail = itemView.findViewById<TextView>(R.id.tv_pricedetail)
//        var tv_country = itemView.findViewById<TextView>(R.id.tv_country)
//        var tv_jobcity = itemView.findViewById<TextView>(R.id.tv_jobcity)

    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        arrayList.add(MM(0))
        Log.d("checkingforsize",arrayList.size.toString())


        holder.imgadd.setOnClickListener {

            var qnt: Int = arrayList.get(position).count
            qnt++
            value++

            arrayList.get(position).count = qnt

             listener.passData(arrayList,qnt,value)

            holder.tvcount.setText(String.valueOf(arrayList.get(position).count))

            holder.imggsub.visibility =View.VISIBLE
        }

        holder.imggsub.setOnClickListener{
            var qnt: Int = arrayList.get(position).count
            if (qnt>0){
                qnt--
                value--
                arrayList.get(position).count = qnt
                listener.passData(arrayList,qnt,value)
                holder.tvcount.setText(String.valueOf(arrayList.get(position).count))
            }



            }




    }
}