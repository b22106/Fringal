package com.app.fringale.StaticModels

class IncreamentdecModel {
    var count:Int?=null

    constructor(count: Int?) {
        this.count = count
    }
}