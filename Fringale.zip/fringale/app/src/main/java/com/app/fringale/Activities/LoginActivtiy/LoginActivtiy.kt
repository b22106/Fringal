package com.app.fringale.Activities.LoginActivtiy

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.app.fringale.R

class LoginActivtiy : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_activtiy)
    }
}