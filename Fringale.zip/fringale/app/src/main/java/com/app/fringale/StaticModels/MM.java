package com.app.fringale.StaticModels;

public class MM {
    int count;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public MM(int count) {
        this.count = count;
    }
}
