package com.app.fringale.Activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.app.fringale.R

class AccountSettingActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_account_setting)
    }
}