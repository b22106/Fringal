package com.app.fringale.interfaces

import com.app.fringale.StaticModels.MM

interface NestedClickListener {
    fun passData(imgadd: ArrayList<MM>, qnt: Int, value: Int)

}